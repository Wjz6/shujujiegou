#include <iostream>
using namespace std;

class Ploy
{
public:
	double coef;
	int expo;
	Ploy(double co, int ex, Ploy* p = NULL) :coef(co), expo(ex), next(p) {};
	Ploy* next;
	Ploy() {};
};
Ploy* shuru(Ploy *head, int n) {
	Ploy *P = NULL;
	for (int i = 1; i <= n; i++)
	{
		double co = 0;
		int ex = 0;
		Ploy *p = new Ploy();
		cout << "�����" << i << "��ֵ" << endl;
		cin >> co >> ex;
		p->coef = co;
		p->expo = ex;
		p->next = NULL;
		if (head == NULL)
		{
			head = p;
			P = head;
		}
		else
		{
			head->next = p;
			head = head->next;
		}
	}
	return P;
}
void shuchu(Ploy *head)
{
	for (; head != NULL; head = head->next)
	{
		if (head->coef == 0) continue;
		if (head->coef == -1) cout << "-";
		else if (head->coef == 1) cout << "";
		else cout << head->coef;
		if (head->expo == 1) cout << "x";
		else cout << "x^" << head->expo;
		if (head->next&&head->next->coef > 0) cout << "+";
	}
}
Ploy* chengfa(Ploy *head1, Ploy *head2)
{
	Ploy *quan = NULL;
	Ploy *head = NULL;
	while (head1 != NULL)
	{
		double co1 = head1->coef;
		int ex1 = head1->expo;
		for (Ploy *h2 = head2; h2 != NULL; h2 = h2->next)
		{
             Ploy *po = new Ploy();
			 po->coef = co1 * h2->coef;
			 po->expo = ex1 + h2->expo;
			 po->next = NULL;
			 if (quan == NULL)
			 {
				 quan = po;
				 head = quan;
			 }
			 else
			 {
				 quan->next = po;
				 quan = quan->next;
			 }
		}
		head1 = head1->next;
	}
	for (Ploy *p = head; p != NULL; p = p->next)
	{
		double co2 = p->coef;
		int ex2 = p->expo;
		for (Ploy *p1 = p->next; p1 != NULL; p1 = p1->next)
		{
			if (p1->expo == ex2)
			{
				p->coef = p->coef + p1->coef;
				p1->coef = 0;
				p1->expo = 0;
			}
		}
	}
	return head;
}
int main()
{
	int answer1, answer2;
	int co, ex;
	Ploy *head1 = NULL;
	Ploy *head2 = NULL;
	Ploy *head3 = NULL;
	cout << "���ʵ�һ������ʽ��Ҫ��������" << endl;
	cin >> answer1;
	cout << "���������ǵ�ϵ����ָ����" << endl;
	head1 = shuru(head1, answer1);
	cout << "����ʽΪ��";
	shuchu(head1);
	cout << endl;
	cout << "���ʵڶ�������ʽ��Ҫ��������" << endl;
	cin >> answer2;
	cout << "���������ǵ�ϵ����ָ����" << endl;
	head2 = shuru(head2, answer2);
	cout << "����ʽΪ��";
	shuchu(head2);
	cout << endl;
	cout << "�����������ʽ��˺�Ľ��" << endl;
	shuchu(chengfa(head1, head2));
}