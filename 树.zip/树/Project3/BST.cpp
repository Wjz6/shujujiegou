#include <iostream>
using namespace std;
#include "BST.h"
int main()
{
	BST<int> intBST;
	cout << "Constructing empty BST\n";
	cout << "BST " << (intBST.empty() ? "is" : "is not") << " empty\n";
    intBST.insert(23);
	intBST.insert(11);
	intBST.insert(56);
	intBST.insert(5);
	intBST.insert(20);
	intBST.insert(30);
	intBST.insert(89);
	intBST.insert(77);
	intBST.insert(45);
	intBST.insert(50);

	cout << "the shape of the tree: " << endl;
	intBST.graph(cout);
	//��������
	cout << "BST " << (intBST.empty() ? "is" : "is not") << " empty\n";
	cout << "zhongxu of BST\n";
	intBST.inorderzhong(cout);
	cout << endl;

	//����ǰ��
	cout << "BST " << (intBST.empty() ? "is" : "is not") << " empty\n";
	cout << "qianxu of BST\n";
	intBST.inorderqian(cout);
	cout << endl;

	//���Ժ���
	cout << "BST " << (intBST.empty() ? "is" : "is not") << " empty\n";	
	cout << "houxu of BST\n";
	intBST.inorderhou(cout);
	cout << endl;
}
