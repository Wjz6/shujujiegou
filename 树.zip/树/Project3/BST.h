#include<iostream>
#include<new>
#include<iomanip>
using namespace std;
#ifndef BINARY_SEARCH_TREE
#define BINARY_SEARCH_TREE

template <typename DataType>
class BST
{
public:
	BST();
	bool empty()const;
	bool search(const DataType & item)const;
	void insert(const DataType & item);
	void remove(const DataType & item);
	void inorderzhong(ostream & out)const;
	void inorderqian(ostream & out)const;
	void inorderhou(ostream & out)const;
	void graph(ostream & out)const;
	~BST();
private:
	class BinNode
	{
	public:
		
		DataType data;
		BinNode * left;
		BinNode * right;
		BinNode() :left(0), right(0) {}
		BinNode(DataType item):data(item),left(0),right(0){}
	};
	typedef BinNode * BinNodePointer;
	void search2(const DataType & item, bool & found, BinNodePointer & locptr, BinNodePointer & parent)const;
	//void inorderAuxzhong(ostream & out, BinNodePointer subtreePtr)const;
	void inorderAuxzhong(ostream & out, BST<DataType>::BinNodePointer subtreePtr)const;
	//void inorderAuxqian(ostream & out, BinNodePointer subtreePtr)const;
	void inorderAuxqian(ostream & out, BST<DataType>::BinNodePointer subtreePtr)const;
	//void inorderAuxhou(ostream & out, BinNodePointer subtreePtr)const;
	void inorderAuxhou(ostream & out, BST<DataType>::BinNodePointer subtreePtr)const;
	void graphAux(ostream & out, int indent, BST<DataType>::BinNodePointer subtreeRoot)const;
	//void graphAux(ostream & out, int indent, BinNodePointer subtreeRoot)const;
	void deletetree(BST<DataType>::BinNodePointer myRoot);
	BinNodePointer myRoot;
};
template <typename DataType>  //���캯��
inline BST<DataType>::BST()
:myRoot(0)
{}

template <typename DataType>
inline bool BST<DataType>::empty() const
{
	return myRoot == 0;
}

template <typename DataType>
bool BST<DataType>::search(const DataType & item)const
{
	BST < DataType>::BinNodePointer locptr = myRoot;
	bool found = false;
	while (!found&&locptr != 0)
	{
		if (item < locptr->data)
			locptr = locptr->left;
		else if (locptr->data < item)
			locptr = locptr->right;
		else
			found = true;
	}
	return found;
}

template <typename DataType>
void BST<DataType>::insert(const DataType&item)
{
	BST<DataType>::BinNodePointer
		locptr = myRoot,
	parent = 0;
	bool found = false;
	while (!found&&locptr != 0)
	{
		parent = locptr;
		if (item < locptr->data)
			locptr = locptr->left;
		else if (locptr->data < item)
			locptr = locptr->right;
		else found = true;
	}
	if (!found)
	{
		locptr = new BST<DataType>::BinNode(item);
		if (parent == 0)
			myRoot = locptr;
		else if (item < parent->data)
			parent->left = locptr;
		else
			parent->right = locptr;
	}
	else
		cout << "Item already in the tree\n";
}

template <typename DataType>
void BST<DataType>::remove(const DataType&item)
{
	bool found;
	BST<DataType>::BinNodePointer
		x,
	parent;
	search2(item, found, x, parent);
	if (!found)
	{
		cout << "Item not in the BST\n";
		return;
	}
	if (x->left != 0 && x->right != 0)
	{
		BST<DataType>::BinNodePointer xSucc = x->right;
		parent = x;
		while (xSucc->left != 0)
		{
			parent = xSucc;
			xSucc = xSucc->left;
		}
		x->data = xSucc->data;
		x = xSucc;
	}
	BST<DataType>::BinNodePointer
		subtree = x->left;
	if (subtree == 0)
		subtree = x->left;
	if (parent == 0)
		myRoot = subtree;
	else if (parent->left == x)
		parent->left = subtree;
	else
		parent->right = subtree;
	delete x;
}

template<class DataType>
void BST<DataType>::search2(const DataType & item, bool & found,
	BST<DataType>::BinNodePointer & locptr,
	BST<DataType>::BinNodePointer & parent)const
{
	locptr = myRoot;
	parent = 0;
	found = false;
	while (!found&&locptr != 0)
	{
		if (item < locptr->data)
		{
			parent = locptr;
			locptr = locptr->left;
		}
		else if (locptr->data < item)
		{
			parent = locptr;
			locptr = locptr->right;
		}
		else
			found = true;
	}
}

template <typename DataType>  //����
inline void BST<DataType>::inorderzhong(ostream & out)const
{
	inorderAuxzhong(out, myRoot);
}

template<typename DataType>
void BST<DataType>::inorderAuxzhong(ostream & out, BST<DataType>::BinNodePointer subtreeRoot)const
{
	if (subtreeRoot != 0)
	{
		inorderAuxzhong(out, subtreeRoot->left);
		out << subtreeRoot->data << " ";
		inorderAuxzhong(out, subtreeRoot->right);
	}
}

template <typename DataType>  //ǰ��
inline void BST<DataType>::inorderqian(ostream & out)const
{
	inorderAuxqian(out, myRoot);
}

template<typename DataType>
void BST<DataType>::inorderAuxqian(ostream & out, BST<DataType>::BinNodePointer subtreeRoot)const
{
	if (subtreeRoot != 0)
	{
		out << subtreeRoot->data << " ";		
		inorderAuxqian(out, subtreeRoot->left);
		inorderAuxqian(out, subtreeRoot->right);
	}
}

template <typename DataType>  //����
inline void BST<DataType>::inorderhou(ostream & out)const
{
	inorderAuxhou(out, myRoot);
}

template<typename DataType>
void BST<DataType>::inorderAuxhou(ostream & out, BST<DataType>::BinNodePointer subtreeRoot)const
{
	if (subtreeRoot != 0)
	{
		out << subtreeRoot->data << " ";
		inorderAuxhou(out, subtreeRoot->right);
		inorderAuxhou(out, subtreeRoot->left);
	}
}

template <typename DataType>
inline void BST<DataType>::graph(ostream & out)const
{
	graphAux(out, 0, myRoot);
}

template <typename DataType>
void BST<DataType>::graphAux(ostream & out, int indent, BST<DataType>::BinNodePointer subtreeRoot)const
{
	if (subtreeRoot != 0)
	{
		graphAux(out, indent + 8, subtreeRoot->right);
		out << setw(indent) << " " << subtreeRoot->data << endl;
		graphAux(out, indent + 8, subtreeRoot->left);
	}
}

template <typename DataType>
BST<DataType>::~BST()
{
	deletetree(myRoot);
	myRoot = NULL;
}

template <typename DataType>
void BST<DataType>::deletetree(BST<DataType>::BinNodePointer myRoot)
{
	if (!myRoot)
	{
		deletetree(myRoot->left);
		deletetree(myRoot->right);
		delete myRoot;
	}
}
#endif 