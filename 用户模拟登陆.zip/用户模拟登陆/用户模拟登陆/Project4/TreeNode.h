#ifndef TREENODE
#define TREENODE
#endif // !TREENODE
#include<iostream>
#include<string>
using namespace std;
class TreeNode
{
public:
	string myName;
	string myPassword;
	TreeNode * left;  //����
	TreeNode * right; //����
	TreeNode(){}; //TreeNode�Ĺ��캯��
	TreeNode(string name, string password, TreeNode * l=NULL, TreeNode * r=NULL)  //TreeNode����ʾ���캯��
	{
		myName = name;
		myPassword = password;
		left = l;
		right = r;
	}
};

