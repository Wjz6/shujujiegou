#include<iostream>
#include<string>
#include"FileStore.h"
#include<fstream>
using namespace std;
string name;
string password;
deque<TreeNode>FileStore::filereader()
{
	deque<TreeNode> list;  //˫�˶���
	string name, password;
	ifstream infile("Data.txt");
	while (infile >> name >> password)
	{
		TreeNode * t = new TreeNode(name, password);
		list.push_back(*t);  //�����ָ����ʽ����ջ��
	}
	return list;
}

void FileStore::filewriter(deque<TreeNode> list)
{
	ofstream outfile("Data.txt");
	for(int i=0;i<list.size();i++)
	{
		if (list[i].myName == "guan")continue;
		else outfile << list[i].myName << " " << list[i].myPassword<<endl;
	}
	outfile.close();
}
