#ifndef FILESTORE
#define FILESTORE
#endif // !FILESTORE
#include<iostream>
#include<string>
#include "TreeNode.h"
#include<deque>
using namespace std;
class FileStore
{
public:
	deque<TreeNode> filereader();//���ݶ���
	void filewriter(deque<TreeNode>list);//�������
};

